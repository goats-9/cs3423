int D3CL(int *x12)
{
    int -a,/a1,+a2c;
    char +b,*z,-1g1iu3gh9813g91g3298g21913g389g1839g8g19tg;
    if (*x12 && 1 == 0) { return 3; }
    else { return 2; }
}

void M41N() { int -2ez = 42069; int -1aml33t = D3CL(-2ez); -1aml33t = -1aml33t + -2ez; return void; }